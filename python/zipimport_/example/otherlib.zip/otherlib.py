def bark():
    print(f"Bark bark! I'm otherlib running from {__file__ = }")
